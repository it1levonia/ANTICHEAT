# MineviaAC Test

A simple test anticheat for Spigot/Paper 1.8.8/1.8.9.

## Important
This version intentionally uses **no ProtocolLib, PacketEvents, Grim API, or other external packet API**.
It uses only normal Bukkit/Spigot events, so it is suitable for testing the UI/VL/staff flow, but it is NOT as accurate as a packet-level production anticheat.

## Included checks
- Fly A/B
- Speed A
- AutoClicker A
- BadPitch A
- Reach A (rough Bukkit-event estimate only)

## Staff flow
- OPs see `[Minevia]` alerts.
- Flags add VL.
- At 100 VL, OPs get clickable `[KICK] [NO KICK]`.
- No automatic ban.
- VL decays over time.

## Build
Install Java 8+ and Maven, then run:

```bash
mvn clean package
```

The jar will be:

```text
target/MineviaAC-Test.jar
```

Put it inside your server's `plugins` folder and restart the test server.

## Commands
- `/mineviaac`
- `/mineviaac info <player>`
- `/mineviaac reset <player>`
- `/mineviaac kick <player>`
- `/mineviaac dismiss <player>`
- `/mineviaac reload`

## Files
- `pom.xml`
- `src/main/resources/plugin.yml`
- `src/main/resources/config.yml`
- Java source under `src/main/java/me/minevia/ac/`

## Warning
Do not treat this test build as proof that someone is cheating.
Bukkit-only reach/movement checks are approximate and can false flag because of ping, lag, knockback, plugins, or unusual map mechanics.
