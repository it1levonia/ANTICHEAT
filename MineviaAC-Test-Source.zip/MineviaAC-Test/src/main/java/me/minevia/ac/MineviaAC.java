package me.minevia.ac;

import me.minevia.ac.command.ACCommand;
import me.minevia.ac.data.PlayerData;
import me.minevia.ac.listener.CombatListener;
import me.minevia.ac.listener.MovementListener;
import me.minevia.ac.listener.PlayerListener;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MineviaAC extends JavaPlugin {

    private final Map<UUID, PlayerData> data = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();

        Bukkit.getPluginManager().registerEvents(new PlayerListener(this), this);
        Bukkit.getPluginManager().registerEvents(new MovementListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CombatListener(this), this);

        getCommand("mineviaac").setExecutor(new ACCommand(this));

        startDecayTask();
        getLogger().info("MineviaAC Test enabled. No external packet API is being used.");
    }

    public PlayerData getData(Player player) {
        PlayerData found = data.get(player.getUniqueId());
        if (found == null) {
            found = new PlayerData(player.getUniqueId());
            data.put(player.getUniqueId(), found);
        }
        return found;
    }

    public void removeData(Player player) {
        data.remove(player.getUniqueId());
    }

    public String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    public String prefix() {
        return color(getConfig().getString("prefix", "&9[Minevia]"));
    }

    public void flag(Player player, String check, int amount, String detail) {
        if (player == null || !player.isOnline()) return;
        if (player.hasPermission("mineviaac.exempt")) return;

        PlayerData pd = getData(player);
        int old = pd.getVl();
        int now = pd.addVl(amount);
        pd.addFlag(check + (detail == null || detail.isEmpty() ? "" : " (" + detail + ")"));

        String msg = prefix() + " " + ChatColor.WHITE + player.getName()
                + ChatColor.GRAY + " flagged " + ChatColor.RED + check
                + ChatColor.GRAY + " (VL: " + now + "/"
                + getConfig().getInt("threshold", 100) + ")";

        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.isOp() || staff.hasPermission("mineviaac.alerts")) {
                staff.sendMessage(msg);
            }
        }
        getLogger().info(ChatColor.stripColor(msg));

        int threshold = getConfig().getInt("threshold", 100);
        if (old < threshold && now >= threshold && !pd.isReviewSent()) {
            pd.setReviewSent(true);
            sendReview(player);
        }
    }

    private void sendReview(Player target) {
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (!(staff.isOp() || staff.hasPermission("mineviaac.kick"))) continue;

            staff.sendMessage(prefix() + " " + ChatColor.RED + target.getName()
                    + " reached " + getConfig().getInt("threshold", 100) + " VL.");

            // Works on Spigot 1.8.8 without ProtocolLib/PacketEvents.
            try {
                net.md_5.bungee.api.chat.TextComponent kick =
                        new net.md_5.bungee.api.chat.TextComponent("[KICK]");
                kick.setColor(net.md_5.bungee.api.ChatColor.GREEN);
                kick.setBold(true);
                kick.setClickEvent(new net.md_5.bungee.api.chat.ClickEvent(
                        net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND,
                        "/mineviaac kick " + target.getName()));

                net.md_5.bungee.api.chat.TextComponent space =
                        new net.md_5.bungee.api.chat.TextComponent("   ");

                net.md_5.bungee.api.chat.TextComponent no =
                        new net.md_5.bungee.api.chat.TextComponent("[NO KICK]");
                no.setColor(net.md_5.bungee.api.ChatColor.GRAY);
                no.setBold(true);
                no.setClickEvent(new net.md_5.bungee.api.chat.ClickEvent(
                        net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND,
                        "/mineviaac dismiss " + target.getName()));

                staff.spigot().sendMessage(kick, space, no);
            } catch (Throwable ignored) {
                staff.sendMessage(ChatColor.GREEN + "[KICK] " + ChatColor.GRAY
                        + "/mineviaac kick " + target.getName());
                staff.sendMessage(ChatColor.GRAY + "[NO KICK] /mineviaac dismiss " + target.getName());
            }
        }
    }

    private void startDecayTask() {
        if (!getConfig().getBoolean("vl-decay.enabled", true)) return;
        long seconds = Math.max(1L, getConfig().getLong("vl-decay.every-seconds", 15));
        final int amount = Math.max(1, getConfig().getInt("vl-decay.amount", 2));

        Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            @Override
            public void run() {
                for (Player online : Bukkit.getOnlinePlayers()) {
                    PlayerData pd = getData(online);
                    pd.decay(amount);
                    if (pd.getVl() < getConfig().getInt("threshold", 100)) {
                        pd.setReviewSent(false);
                    }
                }
            }
        }, seconds * 20L, seconds * 20L);
    }
}
