package me.minevia.ac.command;

import me.minevia.ac.MineviaAC;
import me.minevia.ac.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class ACCommand implements CommandExecutor {
    private final MineviaAC plugin;

    public ACCommand(MineviaAC plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender.isOp() || sender.hasPermission("mineviaac.info"))) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(plugin.prefix() + ChatColor.GRAY + " MineviaAC Test v1.0");
            sender.sendMessage(ChatColor.GRAY + "/" + label + " info <player>");
            sender.sendMessage(ChatColor.GRAY + "/" + label + " reset <player>");
            sender.sendMessage(ChatColor.GRAY + "/" + label + " kick <player>");
            sender.sendMessage(ChatColor.GRAY + "/" + label + " dismiss <player>");
            sender.sendMessage(ChatColor.GRAY + "/" + label + " reload");
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!(sender.isOp() || sender.hasPermission("mineviaac.reload"))) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            plugin.reloadConfig();
            sender.sendMessage(plugin.prefix() + ChatColor.GREEN + " Config reloaded.");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Please specify a player.");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found.");
            return true;
        }

        PlayerData data = plugin.getData(target);

        if (args[0].equalsIgnoreCase("info")) {
            sender.sendMessage(plugin.prefix() + " " + ChatColor.WHITE + target.getName()
                    + ChatColor.GRAY + " VL: " + ChatColor.RED + data.getVl());
            sender.sendMessage(ChatColor.GRAY + "Recent flags:");
            if (data.getRecentFlags().isEmpty()) {
                sender.sendMessage(ChatColor.DARK_GRAY + "None");
            } else {
                for (String flag : data.getRecentFlags()) {
                    sender.sendMessage(ChatColor.DARK_GRAY + "- " + ChatColor.GRAY + flag);
                }
            }
            return true;
        }

        if (args[0].equalsIgnoreCase("reset")) {
            if (!(sender.isOp() || sender.hasPermission("mineviaac.reset"))) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            data.reset();
            sender.sendMessage(plugin.prefix() + ChatColor.GREEN + " Reset " + target.getName() + ".");
            return true;
        }

        if (args[0].equalsIgnoreCase("dismiss")) {
            data.setReviewSent(false);
            sender.sendMessage(plugin.prefix() + ChatColor.GRAY + " Review dismissed for " + target.getName() + ".");
            return true;
        }

        if (args[0].equalsIgnoreCase("kick")) {
            if (!(sender.isOp() || sender.hasPermission("mineviaac.kick"))) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            target.kickPlayer(plugin.color(plugin.getConfig().getString(
                    "kick-message",
                    "&cMinevia\n\n&7You were kicked for repeated anticheat flags."
            )));
            Bukkit.broadcast(plugin.prefix() + ChatColor.GRAY + " " + target.getName()
                    + " was kicked after staff review.", "mineviaac.alerts");
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Unknown subcommand.");
        return true;
    }
}
