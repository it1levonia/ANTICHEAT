package me.minevia.ac.data;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

public final class PlayerData {
    private final UUID uuid;
    private int vl;
    private boolean reviewSent;
    private long joinAt = System.currentTimeMillis();
    private long teleportAt;
    private long velocityAt;
    private long lastMoveAt;
    private long lastAttackAt;
    private int clicksThisSecond;
    private long clickWindow = System.currentTimeMillis();
    private final Deque<String> recentFlags = new ArrayDeque<String>();

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() { return uuid; }
    public int getVl() { return vl; }

    public int addVl(int amount) {
        vl = Math.max(0, vl + amount);
        return vl;
    }

    public void reset() {
        vl = 0;
        reviewSent = false;
        recentFlags.clear();
    }

    public void decay(int amount) {
        vl = Math.max(0, vl - amount);
    }

    public boolean isReviewSent() { return reviewSent; }
    public void setReviewSent(boolean reviewSent) { this.reviewSent = reviewSent; }

    public long getJoinAt() { return joinAt; }
    public void setJoinAt(long joinAt) { this.joinAt = joinAt; }

    public long getTeleportAt() { return teleportAt; }
    public void setTeleportAt(long teleportAt) { this.teleportAt = teleportAt; }

    public long getVelocityAt() { return velocityAt; }
    public void setVelocityAt(long velocityAt) { this.velocityAt = velocityAt; }

    public long getLastMoveAt() { return lastMoveAt; }
    public void setLastMoveAt(long lastMoveAt) { this.lastMoveAt = lastMoveAt; }

    public long getLastAttackAt() { return lastAttackAt; }
    public void setLastAttackAt(long lastAttackAt) { this.lastAttackAt = lastAttackAt; }

    public int registerClickAndGetCps() {
        long now = System.currentTimeMillis();
        if (now - clickWindow >= 1000L) {
            clicksThisSecond = 0;
            clickWindow = now;
        }
        clicksThisSecond++;
        return clicksThisSecond;
    }

    public void addFlag(String flag) {
        recentFlags.addFirst(flag);
        while (recentFlags.size() > 10) recentFlags.removeLast();
    }

    public Deque<String> getRecentFlags() {
        return recentFlags;
    }
}
