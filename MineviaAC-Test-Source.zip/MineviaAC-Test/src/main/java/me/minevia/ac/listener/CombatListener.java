package me.minevia.ac.listener;

import me.minevia.ac.MineviaAC;
import me.minevia.ac.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;

public final class CombatListener implements Listener {
    private final MineviaAC plugin;

    public CombatListener(MineviaAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        if (!plugin.getConfig().getBoolean("checks.autoclicker.enabled", true)) return;

        Player player = event.getPlayer();
        int cps = plugin.getData(player).registerClickAndGetCps();
        int max = plugin.getConfig().getInt("checks.autoclicker.max-cps", 22);

        if (cps > max) {
            plugin.flag(player, "AutoClicker A",
                    plugin.getConfig().getInt("checks.autoclicker.add-vl", 4),
                    "cps=" + cps);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        Player attacker = (Player) event.getDamager();
        Entity target = event.getEntity();

        PlayerData data = plugin.getData(attacker);
        data.setLastAttackAt(System.currentTimeMillis());

        if (!plugin.getConfig().getBoolean("checks.reach.enabled", true)) return;

        Location a = attacker.getEyeLocation();
        Location b = target.getLocation().clone().add(0, target.getHeight() * 0.5, 0);
        double distance = a.distance(b);
        double max = plugin.getConfig().getDouble("checks.reach.max-distance", 3.65D);

        // Bukkit-event reach is only a rough TEST check. Do not use this alone for bans.
        if (distance > max) {
            plugin.flag(attacker, "Reach A",
                    plugin.getConfig().getInt("checks.reach.add-vl", 8),
                    "distance=" + String.format(java.util.Locale.US, "%.2f", distance));
        }
    }
}
