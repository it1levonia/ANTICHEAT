package me.minevia.ac.listener;

import me.minevia.ac.MineviaAC;
import me.minevia.ac.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffectType;

public final class MovementListener implements Listener {
    private final MineviaAC plugin;

    public MovementListener(MineviaAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;

        Player player = event.getPlayer();
        if (shouldSkip(player)) return;

        PlayerData data = plugin.getData(player);
        long now = System.currentTimeMillis();

        if (now - data.getJoinAt() < plugin.getConfig().getLong("grace.join-ms", 3000)) return;
        if (now - data.getTeleportAt() < plugin.getConfig().getLong("grace.teleport-ms", 1500)) return;
        if (now - data.getVelocityAt() < plugin.getConfig().getLong("grace.velocity-ms", 1200)) return;

        Location from = event.getFrom();
        Location to = event.getTo();

        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        double dy = to.getY() - from.getY();

        checkBadPitch(player, to);
        checkSpeed(player, horizontal);
        checkFly(player, from, to, dy);

        data.setLastMoveAt(now);
    }

    private void checkBadPitch(Player player, Location to) {
        if (!plugin.getConfig().getBoolean("checks.badpitch.enabled", true)) return;
        if (Math.abs(to.getPitch()) > 90.0F) {
            plugin.flag(player, "BadPitch A",
                    plugin.getConfig().getInt("checks.badpitch.add-vl", 20),
                    "pitch=" + to.getPitch());
        }
    }

    private void checkSpeed(Player player, double horizontal) {
        if (!plugin.getConfig().getBoolean("checks.speed.enabled", true)) return;

        double max = player.isSprinting() ? 0.79D : 0.62D;
        if (player.hasPotionEffect(PotionEffectType.SPEED)) max += 0.45D;
        if (player.getLocation().getBlock().getType() == Material.ICE
                || player.getLocation().clone().subtract(0, 1, 0).getBlock().getType() == Material.ICE) {
            max += 0.55D;
        }

        if (horizontal > max) {
            plugin.flag(player, "Speed A",
                    plugin.getConfig().getInt("checks.speed.add-vl", 5),
                    "move=" + round(horizontal));
        }
    }

    private void checkFly(Player player, Location from, Location to, double dy) {
        if (!plugin.getConfig().getBoolean("checks.fly.enabled", true)) return;
        if (player.getAllowFlight() || player.isFlying()) return;
        if (player.hasPotionEffect(PotionEffectType.JUMP)) return;
        if (isLiquid(player) || isClimbable(player)) return;

        boolean belowAir = to.clone().subtract(0, 0.1, 0).getBlock().getType() == Material.AIR;
        boolean fromBelowAir = from.clone().subtract(0, 0.1, 0).getBlock().getType() == Material.AIR;

        if (belowAir && fromBelowAir && dy > 0.62D) {
            plugin.flag(player, "Fly A",
                    plugin.getConfig().getInt("checks.fly.add-vl", 8),
                    "dy=" + round(dy));
        }

        if (belowAir && fromBelowAir && Math.abs(dy) < 0.0001D) {
            // Very conservative hover sample; one event adds little VL.
            plugin.flag(player, "Fly B", 1, "hover");
        }
    }

    private boolean shouldSkip(Player player) {
        return player.getGameMode() == GameMode.CREATIVE
                || player.getGameMode() == GameMode.SPECTATOR
                || player.isInsideVehicle()
                || player.isDead();
    }

    private boolean isLiquid(Player p) {
        Material feet = p.getLocation().getBlock().getType();
        Material below = p.getLocation().clone().subtract(0, 1, 0).getBlock().getType();
        return feet == Material.WATER || feet == Material.STATIONARY_WATER
                || feet == Material.LAVA || feet == Material.STATIONARY_LAVA
                || below == Material.WATER || below == Material.STATIONARY_WATER;
    }

    private boolean isClimbable(Player p) {
        Material type = p.getLocation().getBlock().getType();
        return type == Material.LADDER || type == Material.VINE || type == Material.WEB;
    }

    private String round(double d) {
        return String.format(java.util.Locale.US, "%.3f", d);
    }
}
