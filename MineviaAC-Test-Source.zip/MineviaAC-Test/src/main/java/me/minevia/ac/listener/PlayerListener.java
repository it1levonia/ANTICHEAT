package me.minevia.ac.listener;

import me.minevia.ac.MineviaAC;
import me.minevia.ac.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;

public final class PlayerListener implements Listener {
    private final MineviaAC plugin;

    public PlayerListener(MineviaAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        PlayerData data = plugin.getData(event.getPlayer());
        data.setJoinAt(System.currentTimeMillis());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        plugin.getData(event.getPlayer()).setTeleportAt(System.currentTimeMillis());
    }

    @EventHandler
    public void onVelocity(PlayerVelocityEvent event) {
        plugin.getData(event.getPlayer()).setVelocityAt(System.currentTimeMillis());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.removeData(event.getPlayer());
    }

    @EventHandler
    public void onKick(PlayerKickEvent event) {
        plugin.removeData(event.getPlayer());
    }
}
